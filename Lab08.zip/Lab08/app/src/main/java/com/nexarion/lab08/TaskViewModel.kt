package com.nexarion.lab08

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest // Necesario para el filtro
import kotlinx.coroutines.flow.SharingStarted // Necesario para el StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskViewModel(private val dao: TaskDao) : ViewModel() {

    // 1. ESTADO DE FILTRO (Necesario para el filtrado)
    private val _currentFilter = MutableStateFlow(TaskFilter.ALL)
    val currentFilter: StateFlow<TaskFilter> = _currentFilter

    // 2. TAREAS REACTIVAS (Reemplaza _tasks y la lógica manual de recarga)
    // flatMapLatest: Observa los cambios en el filtro y, cuando cambia,
    // inicia una nueva colección del DAO, que es reactiva por sí misma.
    val tasks: StateFlow<List<Task>> = _currentFilter
        .flatMapLatest { filter ->
            // Mapea el enum del filtro al valor booleano que el DAO necesita (is_completed)
            val filterValue = when (filter) {
                TaskFilter.ALL -> null          // null = trae todos
                TaskFilter.PENDING -> false     // false = solo pendientes
                TaskFilter.COMPLETED -> true    // true = solo completadas
            }
            // Llama al nuevo método getFilteredTasks del DAO (que devuelve un Flow)
            dao.getFilteredTasks(filterValue)
        }
        .stateIn(
            scope = viewModelScope,

            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )


    fun addTask(description: String) {
        val newTask = Task(description = description)
        viewModelScope.launch { dao.insertTask(newTask) }

    }

    fun toggleTaskCompletion(task: Task) {
        viewModelScope.launch {
            val updatedTask = task.copy(isCompleted = !task.isCompleted)
            dao.updateTask(updatedTask)
        }
    }


    fun editTask(task: Task, newDescription: String) {
        if (newDescription.isBlank()) return

        viewModelScope.launch {
            val updatedTask = task.copy(description = newDescription)
            dao.updateTask(updatedTask)
        }
    }


    fun deleteTask(task: Task) {
        viewModelScope.launch { dao.deleteTask(task) }
    }


    fun deleteAllTasks() {
        viewModelScope.launch {
            dao.deleteAllTasks()
        }
    }


    fun setFilter(filter: TaskFilter) {
        _currentFilter.value = filter
    }
}