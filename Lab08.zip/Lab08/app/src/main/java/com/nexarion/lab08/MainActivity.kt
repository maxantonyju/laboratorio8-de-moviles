package com.nexarion.lab08

import android.os.Bundle
import android.content.Context // Necesario para el Singleton en TaskDatabase
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.compose.ui.text.style.TextDecoration
import com.nexarion.lab08.ui.theme.Lab08Theme
import kotlinx.coroutines.launch

// ----------------------------------------------------------------------
// CÓDIGO NECESARIO PARA INSTANCIAR EL VIEWMODEL CON PARÁMETROS
// ----------------------------------------------------------------------

// Clase Factory para instanciar el ViewModel
class TaskViewModelFactory(private val dao: TaskDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TaskViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class MainActivity : ComponentActivity() {

    // Instanciación correcta del DAO y la BD como Singleton
    private val database by lazy { TaskDatabase.getDatabase(this) }
    private val taskDao by lazy { database.taskDao() }

    // Uso de 'by viewModels' con el Factory para inyección segura
    private val viewModel: TaskViewModel by viewModels {
        TaskViewModelFactory(taskDao)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Lab08Theme {
                TaskScreen(viewModel)
            }
        }
    }
}

// ----------------------------------------------------------------------
// PANTALLA PRINCIPAL (TaskScreen)
// ----------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskScreen(viewModel: TaskViewModel) {
    // CollectAsState observa los Flows del ViewModel
    val tasks by viewModel.tasks.collectAsState()
    val currentFilter by viewModel.currentFilter.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var newTaskDescription by remember { mutableStateOf("") }

    // Estado para la edición de tareas (null si no hay diálogo abierto)
    var taskToEdit by remember { mutableStateOf<Task?>(null) }

    Scaffold(
        topBar = { TaskTopBar(viewModel, currentFilter) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Sección para Añadir Tarea
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                TextField(
                    value = newTaskDescription,
                    onValueChange = { newTaskDescription = it },
                    label = { Text("Nueva tarea") },
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (newTaskDescription.isNotEmpty()) {
                            viewModel.addTask(newTaskDescription)
                            newTaskDescription = ""
                        }
                    },
                    modifier = Modifier.padding(start = 8.dp).align(Alignment.CenterVertically)
                ) {
                    Text("Agregar")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Lista de Tareas
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(tasks) { task ->
                    TaskItemWithActions(
                        task = task,
                        viewModel = viewModel,
                        onEditClicked = { taskToEdit = it }
                    )
                }
            }

            // Botón de eliminar todas las tareas
            Button(
                onClick = { viewModel.deleteAllTasks() }, // Ya no necesita launch si no se usa coroutineScope
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            ) {
                Text("Eliminar todas las tareas")
            }
        }
    }

    // DIÁLOGO DE EDICIÓN
    taskToEdit?.let { task ->
        EditTaskDialog(
            task = task,
            onDismiss = { taskToEdit = null },
            onConfirm = { newDesc ->
                viewModel.editTask(task, newDesc)
                taskToEdit = null
            }
        )
    }
}

// ----------------------------------------------------------------------
// COMPONENTES INDIVIDUALES
// ----------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskTopBar(viewModel: TaskViewModel, currentFilter: TaskFilter) {
    TopAppBar(
        title = { Text("Lab08 - Tareas") },
        actions = {
            TaskFilterChip(label = "Todas", selected = currentFilter == TaskFilter.ALL) { viewModel.setFilter(TaskFilter.ALL) }
            TaskFilterChip(label = "Pendientes", selected = currentFilter == TaskFilter.PENDING) { viewModel.setFilter(TaskFilter.PENDING) }
            TaskFilterChip(label = "Completadas", selected = currentFilter == TaskFilter.COMPLETED) { viewModel.setFilter(TaskFilter.COMPLETED) }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}


@Composable
fun TaskItemWithActions(
    task: Task,
    viewModel: TaskViewModel,
    onEditClicked: (Task) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Checkbox y Texto de la tarea
        Checkbox(
            checked = task.isCompleted,
            onCheckedChange = { viewModel.toggleTaskCompletion(task) }
        )
        Text(
            text = task.description,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
            textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
        )

        // Botón/Icono de Editar
        IconButton(onClick = { onEditClicked(task) }) {
            Icon(Icons.Filled.Edit, contentDescription = "Editar tarea")
        }

        // Botón/Icono de Eliminar Individual
        IconButton(onClick = { viewModel.deleteTask(task) }) {
            Icon(Icons.Filled.Delete, contentDescription = "Eliminar tarea")
        }
    }
    Divider()
}


@Composable
fun EditTaskDialog(
    task: Task,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newDescription by remember { mutableStateOf(task.description) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar Tarea") },
        text = {
            TextField(
                value = newDescription,
                onValueChange = { newDescription = it },
                label = { Text("Nueva descripción") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(newDescription) },
                enabled = newDescription.isNotBlank()
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

// ----------------------------------------------------------------------
// Preview
// ----------------------------------------------------------------------

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Lab08Theme {
        Greeting("Android")
    }
}