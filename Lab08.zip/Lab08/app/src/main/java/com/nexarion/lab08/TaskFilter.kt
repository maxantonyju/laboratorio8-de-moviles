package com.nexarion.lab08

// Enum que representa los posibles estados de filtro
enum class TaskFilter {
    ALL,        // Mostrar todas las tareas
    PENDING,    // Mostrar solo tareas pendientes (isCompleted = false)
    COMPLETED   // Mostrar solo tareas completadas (isCompleted = true)
}