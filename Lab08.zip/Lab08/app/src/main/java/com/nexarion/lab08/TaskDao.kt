package com.nexarion.lab08

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete // Importar para eliminar individual
import kotlinx.coroutines.flow.Flow // Importar para obtener datos reactivos

@Dao
interface TaskDao {
    @Query("""
        SELECT * FROM tasks 
        WHERE (:filterState IS NULL) OR (is_completed = :filterState) 
        ORDER BY id DESC
    """)
    fun getFilteredTasks(filterState: Boolean?): Flow<List<Task>>


    @Insert
    suspend fun insertTask(task: Task)


    @Update
    suspend fun updateTask(task: Task)


    @Delete
    suspend fun deleteTask(task: Task)

    @Query("DELETE FROM tasks")
    suspend fun deleteAllTasks()
}